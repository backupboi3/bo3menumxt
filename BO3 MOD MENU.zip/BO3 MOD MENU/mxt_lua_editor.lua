CoD.OverlayUtility.ShowToast( "LootBonusDecal", "Change Classnames", "Injection Successful", "t7_callingcard_mp_darkops_chainkiller", "t7_callingcard_mp_darkops_chainkiller")

local class_1 = CoD.CACUtility.GetLoadoutNameFromIndex( Engine.GetPrimaryController(),  5 )
class_1:set( "^6Discord.gg/MXT" )

local class_2 = CoD.CACUtility.GetLoadoutNameFromIndex( Engine.GetPrimaryController(),  6 )
class_2:set( "^7Discord.gg/MXT" )

local class_3 = CoD.CACUtility.GetLoadoutNameFromIndex( Engine.GetPrimaryController(),  7 )
class_3:set( "^8Discord.gg/MXT" )

local class_4 = CoD.CACUtility.GetLoadoutNameFromIndex( Engine.GetPrimaryController(),  8 )
class_4:set( "^9Discord.gg/MXT" )

local class_5 = CoD.CACUtility.GetLoadoutNameFromIndex( Engine.GetPrimaryController(),  9 )
class_5:set( "^0Discord.gg/MXT" )




